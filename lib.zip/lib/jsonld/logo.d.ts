import { FC } from 'react';
export interface LogoJsonLdProps {
    keyOverride?: string;
    logo: string;
    url: string;
}
declare const LogoJsonLd: FC<LogoJsonLdProps>;
export default LogoJsonLd;
