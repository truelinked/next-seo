import { Video } from '../types';
declare const _default: (video: Video, context?: boolean) => string;
export default _default;
