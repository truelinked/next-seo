declare const formatAuthorName: (authorName: string | string[]) => string;
export default formatAuthorName;
