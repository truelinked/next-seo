declare const markup: (jsonld: string) => {
    __html: string;
};
export default markup;
