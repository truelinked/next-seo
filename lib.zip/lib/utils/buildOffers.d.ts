import { Offers } from '../types';
export declare const buildOffers: (offers: Offers) => string;
