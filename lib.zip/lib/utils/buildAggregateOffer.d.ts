import { AggregateOffer } from '../types';
export declare const buildAggregateOffer: (offer: AggregateOffer) => string;
