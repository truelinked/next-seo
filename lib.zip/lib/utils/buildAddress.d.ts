import { Address } from '../types';
declare const _default: (address: Address) => string;
export default _default;
