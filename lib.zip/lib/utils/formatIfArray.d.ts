declare const formatIfArray: (value: string | string[]) => string;
export default formatIfArray;
