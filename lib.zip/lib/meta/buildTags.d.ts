/// <reference types="react" />
import { BuildTagsParams } from '../types';
declare const buildTags: (config: BuildTagsParams) => JSX.Element[];
export default buildTags;
