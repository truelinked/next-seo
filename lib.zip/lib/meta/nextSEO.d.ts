import { Component } from 'react';
import { NextSeoProps } from '../types';
export default class extends Component<NextSeoProps, {}> {
    render(): JSX.Element;
}
