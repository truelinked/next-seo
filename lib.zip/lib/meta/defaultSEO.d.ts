import { Component } from 'react';
import { DefaultSeoProps } from '../types';
export default class extends Component<DefaultSeoProps, {}> {
    render(): JSX.Element;
}
